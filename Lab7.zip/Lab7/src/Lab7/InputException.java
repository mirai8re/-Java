package Lab7;

class InputException extends Exception {
    public InputException(String message) {
        super(message);
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
